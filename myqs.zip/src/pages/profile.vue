<!--<template>-->
<!--  <q-page padding>-->
<!--    &lt;!&ndash; content &ndash;&gt;-->
<!--    <h3>{{ character.name }}</h3>-->
<!--  </q-page>-->
<!--</template>-->

<!--<script>-->
<!--export default {-->
<!--  async created () {-->
<!--    const character = await this.$axios.get('https://www.breakinggbadapi.com/api/characters/{this.$rout.params.id}')-->
<!--    console.log(character.data)-->
<!--    this.character = character.data[0]-->
<!--  },-->
<!--  data () {-->
<!--    return {-->
<!--      character: ''-->
<!--    }-->
<!--  }-->
<!--  // name: 'PageName',-->
<!--}-->
<!--</script>-->
