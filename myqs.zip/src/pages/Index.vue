<template>
  <q-page class="flex flex-center">
    <img
      alt="Quasar logo"
      src="~assets/quasar-logo-full.svg"
    >
    <h3 class="text-blue-grey-8">Welcome to this Website</h3>
  </q-page>
</template>

<script>
export default {
  name: 'PageIndex'
}
</script>
